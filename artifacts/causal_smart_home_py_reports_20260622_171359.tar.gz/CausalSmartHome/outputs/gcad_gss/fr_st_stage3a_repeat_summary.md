# FR-ST Stage 3A Repeat Robustness

Fixed sparse-threshold=0.001. Generation quality only; no downstream AD claim is made.

## Delta Mean

| metric | enhanced-original mean | std |
| --- | ---: | ---: |
| causal_coverage | 0.241618 | 0.055745 |
| low_evidence_rate | -0.238083 | 0.053087 |
| violation_rate | -0.003535 | 0.006366 |
| action_js_to_target | 0.016661 | 0.063993 |
| device_js_to_target | 0.045236 | 0.069651 |
| transition_js_to_target | 0.016264 | 0.013481 |
| tof_kept_rate | 0.040541 | 0.073085 |
| generated_count | 6.000000 | 10.816654 |
| average_sequence_length | -0.100050 | 0.138297 |

## Per Repeat

| repeat | coverage Δ | low evidence Δ | violation Δ | action JS Δ | device JS Δ | transition JS Δ | TOF kept Δ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| r1 | 0.262524 | -0.264036 | 0.001512 | 0.086033 | 0.118906 | 0.023587 | -0.020270 |
| r2 | 0.283888 | -0.273201 | -0.010687 | 0.004015 | 0.036344 | 0.024498 | 0.121622 |
| r3 | 0.178443 | -0.177012 | -0.001430 | -0.040065 | -0.019542 | 0.000706 | 0.020270 |

## Run Paths

- r1: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p001_repeat1/fr_st_stage3a_summary.csv`
- r2: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p001_repeat2/fr_st_stage3a_summary.csv`
- r3: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p001_repeat3/fr_st_stage3a_summary.csv`
