# SP-ST Stage 3A Repeat Robustness

Fixed sparse-threshold=0.0. Generation quality only; no downstream AD claim is made.

## Delta Mean

| metric | enhanced-original mean | std |
| --- | ---: | ---: |
| causal_coverage | 0.050150 | 0.022912 |
| low_evidence_rate | -0.074608 | 0.029480 |
| violation_rate | -0.001229 | 0.001140 |
| action_js_to_target | 0.009639 | 0.008863 |
| device_js_to_target | 0.007797 | 0.005165 |
| transition_js_to_target | 0.001966 | 0.003523 |
| tof_kept_rate | -0.007937 | 0.036370 |
| generated_count | -0.333333 | 1.527525 |
| average_sequence_length | 0.052507 | 0.006439 |

## Per Repeat

| repeat | coverage Δ | low evidence Δ | violation Δ | action JS Δ | device JS Δ | transition JS Δ | TOF kept Δ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| seed2024 | 0.057808 | -0.106725 | -0.002252 | 0.019462 | 0.012762 | 0.005905 | -0.047619 |
| seed2025 | 0.068252 | -0.068318 | -0.001435 | 0.007215 | 0.008175 | 0.000880 | 0.023810 |
| seed2026 | 0.024390 | -0.048780 | 0.000000 | 0.002240 | 0.002453 | -0.000885 | 0.000000 |

## Run Paths

- seed2024: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_stage3a_summary.csv`
- seed2025: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2025/sp_st_stage3a_summary.csv`
- seed2026: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2026/sp_st_stage3a_summary.csv`
