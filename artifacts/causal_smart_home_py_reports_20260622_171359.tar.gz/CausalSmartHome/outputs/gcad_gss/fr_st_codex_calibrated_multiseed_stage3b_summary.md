# FR-ST Stage 3B Repeat Robustness

Codex-calibrated generation setting. SmartGen TOF, target test data, attack data, and Transformer Autoencoder evaluation are unchanged within each run.

## Delta Mean

| metric | enhanced-original mean | std |
| --- | ---: | ---: |
| precision | 0.052013 | 0.070245 |
| recall | 0.000000 | 0.000000 |
| F1 | 0.036024 | 0.049979 |
| FPR | -0.106061 | 0.155118 |
| FNR | 0.000000 | 0.000000 |
| accuracy | 0.053030 | 0.077559 |
| learned_threshold | 0.000025 | 0.000120 |

## Per Seed

| repeat | F1 Δ | FPR Δ | accuracy Δ | precision Δ | recall Δ |
| --- | ---: | ---: | ---: | ---: | ---: |
| seed2024 | 0.089978 | -0.272727 | 0.136364 | 0.128023 | 0.000000 |
| seed2025 | 0.026784 | -0.079545 | 0.039773 | 0.038524 | 0.000000 |
| seed2026 | -0.008690 | 0.034091 | -0.017045 | -0.010510 | 0.000000 |

## Run Paths

- seed2024: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_stage3b_ad/fr_st_codex_calibrated_v3/metrics.json`
- seed2025: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_stage3b_ad/fr_st_codex_calibrated_seed2025/metrics.json`
- seed2026: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_stage3b_ad/fr_st_codex_calibrated_seed2026/metrics.json`
