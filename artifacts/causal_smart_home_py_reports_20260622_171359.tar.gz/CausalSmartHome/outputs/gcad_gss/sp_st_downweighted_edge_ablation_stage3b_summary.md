# SP-ST Stage 3B Repeat Robustness

Codex-calibrated generation setting. SmartGen TOF, target test data, attack data, and Transformer Autoencoder evaluation are unchanged within each run.

## Delta Mean

| metric | enhanced-original mean | std |
| --- | ---: | ---: |
| precision | 0.007646 | 0.052201 |
| recall | 0.099359 | 0.142290 |
| F1 | 0.069549 | 0.117538 |
| FPR | 0.172161 | 0.251326 |
| FNR | -0.099359 | 0.142290 |
| accuracy | -0.036401 | 0.054518 |
| learned_threshold | -0.719396 | 1.084922 |

## Per Seed

| repeat | F1 Δ | FPR Δ | accuracy Δ | precision Δ | recall Δ |
| --- | ---: | ---: | ---: | ---: | ---: |
| seed2024 | 0.002311 | 0.059066 | -0.011676 | -0.041536 | 0.035714 |
| seed2025 | 0.001068 | -0.002747 | 0.001374 | 0.002056 | 0.000000 |
| seed2026 | 0.205269 | 0.460165 | -0.098901 | 0.062417 | 0.262363 |

## Run Paths

- seed2024: `outputs/gcad_gss/sp_st_stage3b_ad_downweighted/sp_st_downweighted_edge_seed2024/metrics.json`
- seed2025: `outputs/gcad_gss/sp_st_stage3b_ad_downweighted/sp_st_downweighted_edge_seed2025/metrics.json`
- seed2026: `outputs/gcad_gss/sp_st_stage3b_ad_downweighted/sp_st_downweighted_edge_seed2026/metrics.json`
