# FR-ST Stage 3A GCAD-GSS Prompt Quality Summary

This summary compares SmartGen original prompt vs SmartGen + GCAD-GSS enhanced prompt at generation-quality level only. No downstream AD claim is made.

## Prompt Check

- top20_edges: `12`
- causal_hints_are_soft: `True`
- original_gss_hints_retained: `True`
- top20_prompt_est_tokens: `5215`
- top10_recommended: `False`
- prompt_diff: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0002/fr_st_prompt_check/prompt_diff.md`

## Metrics

| group | status | causal coverage | violation rate | low evidence | action JS | device JS | transition JS | TOF kept | TOF count | raw count | avg length | note |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| original | ok | 0.230216 | 0.000000 | 0.769784 | 0.501563 | 0.311158 | 0.893660 | 0.939189 | 139 | 148 | 3.237410 |  |
| enhanced | ok | 0.500000 | 0.250000 | 0.500000 | 0.654893 | 0.583885 | 1.000000 | 1.000000 | 148 | 148 | 3.000000 |  |

## Commands

- original generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage generate --groups original --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex --require-cuda --sparse-threshold 0.0002 --epochs 80 --sample-limit 64 --output-tag fr_st_thr_0p0002`
- original TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage tof --groups original --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex --require-cuda --sparse-threshold 0.0002 --epochs 80 --sample-limit 64 --output-tag fr_st_thr_0p0002`
- original generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0002/fr_st_original/generation_manifest.json`
- original tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0002/fr_st_original/tof_manifest.json`
- original quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0002/fr_st_original/quality_eval_manifest.json`
- enhanced generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage generate --groups enhanced --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex --require-cuda --sparse-threshold 0.0002 --epochs 80 --sample-limit 64 --output-tag fr_st_thr_0p0002`
- enhanced TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage tof --groups enhanced --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex --require-cuda --sparse-threshold 0.0002 --epochs 80 --sample-limit 64 --output-tag fr_st_thr_0p0002`
- enhanced generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0002/fr_st_enhanced/generation_manifest.json`
- enhanced tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0002/fr_st_enhanced/tof_manifest.json`
- enhanced quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0002/fr_st_enhanced/quality_eval_manifest.json`
