# SP-ST Stage 3B Repeat Robustness

Codex-calibrated generation setting. SmartGen TOF, target test data, attack data, and Transformer Autoencoder evaluation are unchanged within each run.

## Delta Mean

| metric | enhanced-original mean | std |
| --- | ---: | ---: |
| precision | -0.194777 | 0.245231 |
| recall | -0.142399 | 0.344614 |
| F1 | -0.177483 | 0.314093 |
| FPR | 0.024725 | 0.052791 |
| FNR | 0.142399 | 0.344614 |
| accuracy | -0.083562 | 0.195101 |
| learned_threshold | -1.096781 | 2.197973 |

## Per Seed

| repeat | F1 Δ | FPR Δ | accuracy Δ | precision Δ | recall Δ |
| --- | ---: | ---: | ---: | ---: | ---: |
| seed2024 | -0.526925 | 0.083791 | -0.302198 | -0.460308 | -0.520604 |
| seed2025 | 0.081333 | 0.008242 | 0.072802 | 0.023183 | 0.153846 |
| seed2026 | -0.086857 | -0.017857 | -0.021291 | -0.147205 | -0.060440 |

## Run Paths

- seed2024: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_stage3b_ad/sp_st_codex_calibrated_seed2024/metrics.json`
- seed2025: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_stage3b_ad/sp_st_codex_calibrated_seed2025/metrics.json`
- seed2026: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_stage3b_ad/sp_st_codex_calibrated_seed2026/metrics.json`
