# FR-ST Stage 3A GCAD-GSS Prompt Quality Summary

This summary compares SmartGen original prompt vs SmartGen + GCAD-GSS enhanced prompt at generation-quality level only. No downstream AD claim is made.

## Prompt Check

- top20_edges: `1`
- causal_hints_are_soft: `True`
- original_gss_hints_retained: `True`
- top20_prompt_est_tokens: `4923`
- top10_recommended: `False`
- prompt_diff: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_prompt_check/prompt_diff.md`

## Metrics

| group | status | causal coverage | violation rate | low evidence | action JS | device JS | transition JS | TOF kept | TOF count | raw count | avg length | note |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| original | ok | 0.630631 | 0.000000 | 0.369369 | 0.477562 | 0.246326 | 0.804821 | 1.000000 | 222 | 222 | 4.932432 |  |
| enhanced | ok | 0.585084 | 0.058818 | 0.356098 | 0.427362 | 0.213462 | 0.819145 | 0.923423 | 205 | 222 | 5.434146 |  |

## Commands

- original generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage generate --groups original --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --sparse-threshold 0.001 --epochs 80 --sample-limit 64 --seed 2026 --samples-per-category 6 --output-tag fr_st_codex_calibrated_seed2026`
- original TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage tof --groups original --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --sparse-threshold 0.001 --epochs 80 --sample-limit 64 --seed 2026 --samples-per-category 6 --output-tag fr_st_codex_calibrated_seed2026`
- original generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_original/generation_manifest.json`
- original tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_original/tof_manifest.json`
- original quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_original/quality_eval_manifest.json`
- enhanced generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage generate --groups enhanced --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --sparse-threshold 0.001 --epochs 80 --sample-limit 64 --seed 2026 --samples-per-category 6 --output-tag fr_st_codex_calibrated_seed2026`
- enhanced TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage tof --groups enhanced --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --sparse-threshold 0.001 --epochs 80 --sample-limit 64 --seed 2026 --samples-per-category 6 --output-tag fr_st_codex_calibrated_seed2026`
- enhanced generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_enhanced/generation_manifest.json`
- enhanced tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_enhanced/tof_manifest.json`
- enhanced quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_enhanced/quality_eval_manifest.json`
