# SP-ST Causal Edge Diagnostic

This diagnostic compares original vs GCAD-GSS enhanced SP-ST TOF outputs across seeds 2024, 2025, and 2026.

## Summary

- Device JS delta mean: `0.007797`.
- Action JS delta mean: `0.009639`.
- Positive JS delta means enhanced moved farther from the SP spring target distribution.
- The SP GCAD prior is very low-weight; the useful signal is visible in causal coverage/low evidence, but endpoint distribution pressure is not aligned with the target distribution.

## Edges Most Associated With Distribution/Order Shifts

| source | target | weight | source gap Δ | target gap Δ | cooccur Δ | order-rate Δ |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Fan | Television | 0.000099 | 0.002546 | 0.014286 | 0.036412 | 0.111700 |
| AirConditioner | Television | 0.000138 | 0.000269 | 0.014286 | 0.037317 | 0.068122 |
| Camera | Television | 0.000099 | 0.000037 | 0.014286 | 0.037344 | 0.088889 |
| Refrigerator | Television | 0.000077 | 0.002590 | 0.014286 | -0.008798 | -0.111111 |
| GarageDoor | Television | 0.000109 | 0.002259 | 0.014286 | 0.000000 | n/a |
| Other | Television | 0.000181 | 0.000084 | 0.014286 | -0.000250 | 0.000000 |
| Dryer | Television | 0.000071 | 0.000024 | 0.014286 | 0.000000 | 0.000000 |
| SmartLock | Television | 0.000163 | 0.000000 | 0.014286 | 0.000000 | n/a |
| SmartPlug | Television | 0.000083 | 0.000000 | 0.014286 | 0.000000 | n/a |
| Projector | Television | 0.000068 | 0.000000 | 0.014286 | 0.000000 | n/a |
| NetworkAudio | Television | 0.000074 | -0.000109 | 0.014286 | 0.000000 | n/a |
| SmartLock | Other | 0.000069 | 0.000000 | 0.000084 | 0.000000 | n/a |

## Top Device Gaps Worsened By Enhanced

| name | gap Δ | enhanced-original freq | original freq | enhanced freq | target freq |
| --- | ---: | ---: | ---: | ---: | ---: |
| Television | 0.014286 | 0.014286 | 0.169183 | 0.183469 | 0.031471 |
| Blind | 0.003377 | 0.003377 | 0.083871 | 0.087248 | 0.000000 |
| Refrigerator | 0.002590 | -0.002590 | 0.038009 | 0.035418 | 0.059730 |
| Fan | 0.002546 | -0.002546 | 0.116959 | 0.114413 | 0.657675 |
| AirConditioner | 0.002352 | -0.002352 | 0.094842 | 0.092490 | 0.123956 |
| GarageDoor | 0.002259 | -0.002259 | 0.006378 | 0.004119 | 0.012845 |
| AirPurifier | 0.000379 | 0.000379 | 0.071737 | 0.072116 | 0.000000 |
| WaterValve | 0.000281 | 0.000281 | 0.018768 | 0.019049 | 0.000000 |
| Heater | 0.000165 | 0.000165 | 0.018890 | 0.019056 | 0.000000 |
| Other | 0.000084 | -0.000084 | 0.002208 | 0.002123 | 0.011561 |
| Camera | 0.000037 | 0.000037 | 0.070364 | 0.070401 | 0.000000 |
| Dryer | 0.000024 | -0.000024 | 0.002020 | 0.001996 | 0.043031 |

## Top Device Gaps Improved By Enhanced

| name | gap Δ | enhanced-original freq | original freq | enhanced freq | target freq |
| --- | ---: | ---: | ---: | ---: | ---: |
| RobotCleaner | -0.002969 | -0.002969 | 0.095975 | 0.093006 | 0.000000 |
| Light | -0.002767 | -0.002767 | 0.194956 | 0.192189 | 0.056519 |
| AirPurifier | -0.002030 | -0.002030 | 0.072239 | 0.070209 | 0.000000 |
| Camera | -0.001864 | -0.001864 | 0.072434 | 0.070570 | 0.000000 |
| Blind | -0.000985 | -0.000985 | 0.102597 | 0.101613 | 0.000000 |
| AirConditioner | -0.000177 | 0.000177 | 0.094745 | 0.094922 | 0.123956 |
| NetworkAudio | -0.000163 | -0.000163 | 0.006342 | 0.006179 | 0.000000 |
| SmartLock | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.003211 |
| Dryer | 0.000024 | -0.000024 | 0.002020 | 0.001996 | 0.043031 |
| Other | 0.000084 | -0.000084 | 0.002208 | 0.002123 | 0.011561 |
| WaterValve | 0.000103 | 0.000103 | 0.014720 | 0.014823 | 0.000000 |
| GarageDoor | 0.000163 | -0.000163 | 0.006342 | 0.006179 | 0.012845 |

## Top Action Gaps Worsened By Enhanced

| name | gap Δ | enhanced-original freq | original freq | enhanced freq | target freq |
| --- | ---: | ---: | ---: | ---: | ---: |
| Television:audioMute mute | 0.015012 | 0.015012 | 0.004171 | 0.019183 | 0.000000 |
| RobotCleaner:setRobotCleanerCleaningMode auto | 0.007231 | 0.007231 | 0.012903 | 0.020134 | 0.000000 |
| Television:setAmbientOn | 0.006711 | 0.006711 | 0.000000 | 0.006711 | 0.000000 |
| Television:audioMute unmute | 0.006369 | 0.006369 | 0.000000 | 0.006369 | 0.000000 |
| Light:setLightingMode | 0.006369 | 0.006369 | 0.000000 | 0.006369 | 0.000000 |
| Camera:imageCapture take | 0.006116 | 0.006116 | 0.006623 | 0.012739 | 0.000000 |
| AirPurifier:switch on | 0.005610 | 0.005610 | 0.019868 | 0.025478 | 0.000000 |
| Camera:notification | 0.003377 | 0.003377 | 0.083871 | 0.087248 | 0.000000 |
| Television:volumeDown | 0.002598 | 0.002598 | 0.064516 | 0.067114 | 0.027617 |
| Light:setColor | 0.002598 | 0.002598 | 0.064516 | 0.067114 | 0.047527 |
| Fan:switch on | 0.002460 | -0.002460 | 0.087088 | 0.084628 | 0.319204 |
| Refrigerator:samsungce.powerCool activate | 0.002175 | -0.002175 | 0.004171 | 0.001996 | 0.058446 |

## Top Action Gaps Improved By Enhanced

| name | gap Δ | enhanced-original freq | original freq | enhanced freq | target freq |
| --- | ---: | ---: | ---: | ---: | ---: |
| Television:audioMute unmute | -0.006452 | -0.006452 | 0.006452 | 0.000000 | 0.000000 |
| Camera:switch on | -0.006452 | -0.006452 | 0.006452 | 0.000000 | 0.000000 |
| Light:setLightingMode | -0.006452 | -0.006452 | 0.006452 | 0.000000 | 0.000000 |
| AirPurifier:switch on | -0.005412 | -0.005412 | 0.032258 | 0.026846 | 0.000000 |
| RobotCleaner:setRobotCleanerMovement cleaning | -0.004879 | -0.004879 | 0.055628 | 0.050749 | 0.000000 |
| GarageDoor:doorControl open | -0.002598 | -0.006452 | 0.006452 | 0.000000 | 0.001927 |
| Television:setChannel | -0.002559 | -0.002559 | 0.081084 | 0.078526 | 0.000000 |
| Light:switch on | -0.002439 | -0.002439 | 0.048688 | 0.046249 | 0.008992 |
| Blind:windowShade open | -0.001899 | -0.001899 | 0.064258 | 0.062359 | 0.000000 |
| Television:volumeDown | -0.001792 | -0.001792 | 0.084347 | 0.082555 | 0.027617 |
| Light:setColor | -0.001628 | -0.001628 | 0.063416 | 0.061787 | 0.047527 |
| Camera:notification | -0.001303 | -0.001303 | 0.050732 | 0.049430 | 0.000000 |

## Diagnosis

- Enhanced consistently reduces low-evidence in Stage 3A, but this diagnostic shows the injected edge endpoints can increase gap-to-target for several high-impact devices/actions.
- The most suspicious pattern is not one bad seed; the mean action/device JS deltas are both positive across the three-seed aggregate.
- The next ablation should reduce endpoint pressure before adding new environments: try smaller top-k values and endpoint filters for edges whose source or target is already overrepresented relative to SP spring target data.

## Artifacts

- json: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_causal_edge_diagnostic.json`
- markdown: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_causal_edge_diagnostic.md`
- edge_csv: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_causal_edge_diagnostic_edges.csv`
