# SP-ST Guarded-Edge Stage 3A Ablation

Guard mode: `target-overrepresented`; each seed uses its own original prompt TOF output as reference and SP spring target as the target distribution.

## Delta Mean Versus Original

| metric | unguarded mean | unguarded std | guarded mean | guarded std | guarded - unguarded mean |
| --- | ---: | ---: | ---: | ---: | ---: |
| low_evidence_rate | -0.074608 | 0.029480 | -0.049071 | 0.069520 | 0.025537 |
| action_js_to_target | 0.009639 | 0.008863 | -0.009070 | 0.015519 | -0.018709 |
| device_js_to_target | 0.007797 | 0.005165 | -0.012174 | 0.004035 | -0.019971 |
| causal_coverage | 0.050150 | 0.022912 | 0.031360 | 0.067378 | -0.018790 |
| violation_rate | -0.001229 | 0.001140 | 0.010699 | 0.003738 | 0.011929 |
| transition_js_to_target | 0.001966 | 0.003523 | 0.000545 | 0.002610 | -0.001421 |
| tof_kept_rate | -0.007937 | 0.036370 | -0.015873 | 0.099127 | -0.007937 |

## Per Seed

| seed | low evidence guarded Δ | action JS guarded Δ | device JS guarded Δ | coverage guarded Δ | TOF kept guarded Δ |
| --- | ---: | ---: | ---: | ---: | ---: |
| seed2024 | -0.023392 | 0.007493 | -0.014326 | -0.006390 | -0.047619 |
| seed2025 | -0.127778 | -0.023276 | -0.007520 | 0.109150 | 0.095238 |
| seed2026 | 0.003955 | -0.011426 | -0.014676 | -0.008681 | -0.095238 |

## Interpretation

- Guarding overrepresented target endpoints mainly tests whether suppressing `* -> Television` edges fixes SP-ST distribution drift.
- A negative `guarded - unguarded` value for action/device JS means the guard moved enhanced outputs closer to SP spring target distribution than the unguarded enhanced prompt.
- Compare low evidence and causal coverage deltas to check how much causal/evidence benefit is lost by the guard.
