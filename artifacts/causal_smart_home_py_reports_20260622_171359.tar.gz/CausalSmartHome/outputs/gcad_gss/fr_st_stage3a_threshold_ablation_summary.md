# FR-ST Stage 3A Sparse Threshold Ablation

This compares generation quality only. No downstream AD claim is made.

| threshold | status | edges | tokens | coverage delta | low evidence delta | transition JS delta | TOF kept delta | action JS delta | device JS delta |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0.001 | ok | 1 | 4923 | 0.032196 | -0.032196 | -0.001168 | 0.013514 | -0.010058 | -0.009074 |
| 0.0005 | ok | 2 | 4947 | 0.023209 | -0.023209 | 0.021394 | 0.047297 | 0.080838 | 0.111312 |
| 0.0002 | ok | 12 | 5215 | 0.269784 | -0.269784 | 0.106340 | 0.060811 | 0.153330 | 0.272727 |

## Run Paths

- 0.001: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p001/fr_st_stage3a_summary.csv`
- 0.0005: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0005/fr_st_stage3a_summary.csv`
- 0.0002: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_thr_0p0002/fr_st_stage3a_summary.csv`
