# Stage 3B AD Check: SP-ST GCAD-GSS Prompt

## Protocol

- Dataset: SP-ST only.
- Compared synthetic spring sequences from Stage 3A after SmartGen TOF.
- The two arms reuse the same SmartGen AD wrapper, target test data, attack data, seed, split ratio, epochs, and threshold percentile.
- No SmartGuard training was run.
- This is a downstream AD check, not a claim that GCAD-GSS improves every AD setting.

## Metrics

| group | precision | recall | F1 | FPR | FNR | accuracy | TP | TN | FP | FN | threshold | synthetic |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| original_prompt | 0.780731 | 0.645604 | 0.706767 | 0.181319 | 0.354396 | 0.732143 | 470 | 596 | 132 | 258 | 5.419061 | 38 |
| enhanced_prompt | 0.739195 | 0.681319 | 0.709078 | 0.240385 | 0.318681 | 0.720467 | 496 | 553 | 175 | 232 | 5.176290 | 39 |

## Delta Enhanced Minus Original

- delta_precision: `-0.041536`
- delta_recall: `0.035714`
- delta_F1: `0.002311`
- delta_FPR: `0.059066`
- delta_FNR: `-0.035714`
- delta_accuracy: `-0.011676`
- delta_learned_threshold: `-0.242771`

## Used Data

- original_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_original/smartgen_tof.pkl`
- enhanced_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_downweighted_edge_seed2024/sp_st_enhanced/smartgen_tof.pkl`
- attack_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/attack/sp/labeled_sp_spring_attack_heater.pkl`
- target_test_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/test/sp/spring/test.pkl`

## Settings

- epochs: `15`
- seed: `2024`
- split_ratio: `0.8`
- device: `cpu`
- cuda_visible_devices: `0`
- threshold_percentage: `95.0`
- dry_run: `False`
