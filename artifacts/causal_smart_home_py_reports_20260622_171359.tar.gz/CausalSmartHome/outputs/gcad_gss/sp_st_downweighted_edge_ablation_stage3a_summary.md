# SP-ST Downweighted-Edge Stage 3A Ablation

Guard mode: target-overrepresented-downweight with factor 0.25; each seed uses its own original prompt TOF output as reference and SP spring target as the target distribution. Overrepresented endpoint edges are retained, downweighted, and reordered instead of removed.

## Delta Mean Versus Original

| metric | unguarded mean | unguarded std | guarded mean | guarded std | guarded - unguarded mean |
| --- | ---: | ---: | ---: | ---: | ---: |
| low_evidence_rate | -0.074608 | 0.029480 | -0.021898 | 0.006546 | 0.052710 |
| action_js_to_target | 0.009639 | 0.008863 | 0.010527 | 0.009011 | 0.000888 |
| device_js_to_target | 0.007797 | 0.005165 | -0.004500 | 0.004051 | -0.012297 |
| causal_coverage | 0.050150 | 0.022912 | -0.001583 | 0.024566 | -0.051733 |
| violation_rate | -0.001229 | 0.001140 | -0.001122 | 0.004373 | 0.000107 |
| transition_js_to_target | 0.001966 | 0.003523 | -0.002600 | 0.003889 | -0.004566 |
| tof_kept_rate | -0.007937 | 0.036370 | -0.023810 | 0.062994 | -0.015873 |

## Per Seed

| seed | low evidence guarded Δ | action JS guarded Δ | device JS guarded Δ | coverage guarded Δ | TOF kept guarded Δ |
| --- | ---: | ---: | ---: | ---: | ---: |
| seed2024 | -0.014845 | 0.016665 | -0.009178 | -0.006874 | 0.023810 |
| seed2025 | -0.027778 | 0.000182 | -0.002132 | 0.025197 | 0.000000 |
| seed2026 | -0.023072 | 0.014733 | -0.002191 | -0.023072 | -0.095238 |

## Interpretation

- Guarding overrepresented target endpoints mainly tests whether suppressing `* -> Television` edges fixes SP-ST distribution drift.
- A negative `guarded - unguarded` value for action/device JS means the guard moved enhanced outputs closer to SP spring target distribution than the unguarded enhanced prompt.
- Compare low evidence and causal coverage deltas to check how much causal/evidence benefit is lost by the guard.
