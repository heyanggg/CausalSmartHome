# Stage 3B AD Check: FR-ST GCAD-GSS Prompt

## Protocol

- Dataset: FR-ST only.
- Compared synthetic spring sequences from Stage 3A after SmartGen TOF.
- The two arms reuse the same SmartGen AD wrapper, target test data, attack data, seed, split ratio, epochs, and threshold percentile.
- No SmartGuard training was run.
- This is a downstream AD check, not a claim that GCAD-GSS improves every AD setting.

## Metrics

| group | precision | recall | F1 | FPR | FNR | accuracy | TP | TN | FP | FN | threshold | synthetic |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| original_prompt | 0.500000 | 1.000000 | 0.666667 | 1.000000 | 0.000000 | 0.500000 | 88 | 0 | 88 | 0 | 0.000011 | 442 |
| enhanced_prompt | 0.500000 | 1.000000 | 0.666667 | 1.000000 | 0.000000 | 0.500000 | 88 | 0 | 88 | 0 | 0.000015 | 424 |

## Delta Enhanced Minus Original

- delta_precision: `0.000000`
- delta_recall: `0.000000`
- delta_F1: `0.000000`
- delta_FPR: `0.000000`
- delta_FNR: `0.000000`
- delta_accuracy: `0.000000`
- delta_learned_threshold: `0.000003`

## Used Data

- original_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_authored_v2/fr_st_original/smartgen_tof.pkl`
- enhanced_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_authored_v2/fr_st_enhanced/smartgen_tof.pkl`
- attack_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/attack/fr/labeled_fr_spring_attack_heater.pkl`
- target_test_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/test/fr/spring/test.pkl`

## Settings

- epochs: `15`
- seed: `2024`
- split_ratio: `0.8`
- device: `cuda`
- cuda_visible_devices: `0`
- threshold_percentage: `95.5`
- dry_run: `False`
