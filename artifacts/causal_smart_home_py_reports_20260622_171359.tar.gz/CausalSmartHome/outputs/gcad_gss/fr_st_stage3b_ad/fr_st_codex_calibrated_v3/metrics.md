# Stage 3B AD Check: FR-ST GCAD-GSS Prompt

## Protocol

- Dataset: FR-ST only.
- Compared synthetic spring sequences from Stage 3A after SmartGen TOF.
- The two arms reuse the same SmartGen AD wrapper, target test data, attack data, seed, split ratio, epochs, and threshold percentile.
- No SmartGuard training was run.
- This is a downstream AD check, not a claim that GCAD-GSS improves every AD setting.

## Metrics

| group | precision | recall | F1 | FPR | FNR | accuracy | TP | TN | FP | FN | threshold | synthetic |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| original_prompt | 0.624113 | 1.000000 | 0.768559 | 0.602273 | 0.000000 | 0.698864 | 88 | 35 | 53 | 0 | 0.000059 | 207 |
| enhanced_prompt | 0.752137 | 1.000000 | 0.858537 | 0.329545 | 0.000000 | 0.835227 | 88 | 59 | 29 | 0 | 0.000222 | 209 |

## Delta Enhanced Minus Original

- delta_precision: `0.128023`
- delta_recall: `0.000000`
- delta_F1: `0.089978`
- delta_FPR: `-0.272727`
- delta_FNR: `0.000000`
- delta_accuracy: `0.136364`
- delta_learned_threshold: `0.000163`

## Used Data

- original_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_original/smartgen_tof.pkl`
- enhanced_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_enhanced/smartgen_tof.pkl`
- attack_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/attack/fr/labeled_fr_spring_attack_heater.pkl`
- target_test_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/test/fr/spring/test.pkl`

## Settings

- epochs: `15`
- seed: `2024`
- split_ratio: `0.8`
- device: `cuda`
- cuda_visible_devices: `0`
- threshold_percentage: `95.5`
- dry_run: `False`
