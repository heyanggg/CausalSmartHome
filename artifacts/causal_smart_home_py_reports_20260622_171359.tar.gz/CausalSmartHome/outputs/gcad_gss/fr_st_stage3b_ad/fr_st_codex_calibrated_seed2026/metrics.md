# Stage 3B AD Check: FR-ST GCAD-GSS Prompt

## Protocol

- Dataset: FR-ST only.
- Compared synthetic spring sequences from Stage 3A after SmartGen TOF.
- The two arms reuse the same SmartGen AD wrapper, target test data, attack data, seed, split ratio, epochs, and threshold percentile.
- No SmartGuard training was run.
- This is a downstream AD check, not a claim that GCAD-GSS improves every AD setting.

## Metrics

| group | precision | recall | F1 | FPR | FNR | accuracy | TP | TN | FP | FN | threshold | synthetic |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| original_prompt | 0.560510 | 1.000000 | 0.718367 | 0.784091 | 0.000000 | 0.607955 | 88 | 19 | 69 | 0 | 0.000066 | 222 |
| enhanced_prompt | 0.550000 | 1.000000 | 0.709677 | 0.818182 | 0.000000 | 0.590909 | 88 | 16 | 72 | 0 | 0.000024 | 205 |

## Delta Enhanced Minus Original

- delta_precision: `-0.010510`
- delta_recall: `0.000000`
- delta_F1: `-0.008690`
- delta_FPR: `0.034091`
- delta_FNR: `0.000000`
- delta_accuracy: `-0.017045`
- delta_learned_threshold: `-0.000043`

## Used Data

- original_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_original/smartgen_tof.pkl`
- enhanced_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_enhanced/smartgen_tof.pkl`
- attack_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/attack/fr/labeled_fr_spring_attack_heater.pkl`
- target_test_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/test/fr/spring/test.pkl`

## Settings

- epochs: `15`
- seed: `2026`
- split_ratio: `0.8`
- device: `cuda`
- cuda_visible_devices: `0`
- threshold_percentage: `95.5`
- dry_run: `False`
