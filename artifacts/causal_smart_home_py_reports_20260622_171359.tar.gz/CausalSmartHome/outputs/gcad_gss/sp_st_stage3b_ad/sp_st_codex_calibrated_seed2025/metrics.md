# Stage 3B AD Check: SP-ST GCAD-GSS Prompt

## Protocol

- Dataset: SP-ST only.
- Compared synthetic spring sequences from Stage 3A after SmartGen TOF.
- The two arms reuse the same SmartGen AD wrapper, target test data, attack data, seed, split ratio, epochs, and threshold percentile.
- No SmartGuard training was run.
- This is a downstream AD check, not a claim that GCAD-GSS improves every AD setting.

## Metrics

| group | precision | recall | F1 | FPR | FNR | accuracy | TP | TN | FP | FN | threshold | synthetic |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| original_prompt | 0.777045 | 0.809066 | 0.792732 | 0.232143 | 0.190934 | 0.788462 | 589 | 559 | 169 | 139 | 2.904624 | 36 |
| enhanced_prompt | 0.800228 | 0.962912 | 0.874065 | 0.240385 | 0.037088 | 0.861264 | 701 | 553 | 175 | 27 | 1.780555 | 37 |

## Delta Enhanced Minus Original

- delta_precision: `0.023183`
- delta_recall: `0.153846`
- delta_F1: `0.081333`
- delta_FPR: `0.008242`
- delta_FNR: `-0.153846`
- delta_accuracy: `0.072802`
- delta_learned_threshold: `-1.124069`

## Used Data

- original_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2025/sp_st_original/smartgen_tof.pkl`
- enhanced_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2025/sp_st_enhanced/smartgen_tof.pkl`
- attack_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/attack/sp/labeled_sp_spring_attack_heater.pkl`
- target_test_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/test/sp/spring/test.pkl`

## Settings

- epochs: `15`
- seed: `2025`
- split_ratio: `0.8`
- device: `cpu`
- cuda_visible_devices: `0`
- threshold_percentage: `95.0`
- dry_run: `False`
