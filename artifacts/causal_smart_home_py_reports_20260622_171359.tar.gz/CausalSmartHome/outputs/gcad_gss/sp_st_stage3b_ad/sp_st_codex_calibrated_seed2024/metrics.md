# Stage 3B AD Check: SP-ST GCAD-GSS Prompt

## Protocol

- Dataset: SP-ST only.
- Compared synthetic spring sequences from Stage 3A after SmartGen TOF.
- The two arms reuse the same SmartGen AD wrapper, target test data, attack data, seed, split ratio, epochs, and threshold percentile.
- No SmartGuard training was run.
- This is a downstream AD check, not a claim that GCAD-GSS improves every AD setting.

## Metrics

| group | precision | recall | F1 | FPR | FNR | accuracy | TP | TN | FP | FN | threshold | synthetic |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| original_prompt | 0.780731 | 0.645604 | 0.706767 | 0.181319 | 0.354396 | 0.732143 | 470 | 596 | 132 | 258 | 5.419061 | 38 |
| enhanced_prompt | 0.320423 | 0.125000 | 0.179842 | 0.265110 | 0.875000 | 0.429945 | 91 | 535 | 193 | 637 | 2.138078 | 36 |

## Delta Enhanced Minus Original

- delta_precision: `-0.460308`
- delta_recall: `-0.520604`
- delta_F1: `-0.526925`
- delta_FPR: `0.083791`
- delta_FNR: `0.520604`
- delta_accuracy: `-0.302198`
- delta_learned_threshold: `-3.280983`

## Used Data

- original_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_original/smartgen_tof.pkl`
- enhanced_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_enhanced/smartgen_tof.pkl`
- attack_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/attack/sp/labeled_sp_spring_attack_heater.pkl`
- target_test_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/test/sp/spring/test.pkl`

## Settings

- epochs: `15`
- seed: `2024`
- split_ratio: `0.8`
- device: `cpu`
- cuda_visible_devices: `0`
- threshold_percentage: `95.0`
- dry_run: `False`
