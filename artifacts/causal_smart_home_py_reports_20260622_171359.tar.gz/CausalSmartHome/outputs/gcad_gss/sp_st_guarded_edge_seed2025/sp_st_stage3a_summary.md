# SP-ST Stage 3A GCAD-GSS Prompt Quality Summary

This summary compares SmartGen original prompt vs SmartGen + GCAD-GSS enhanced prompt at generation-quality level only. No downstream AD claim is made.

## Prompt Check

- top20_edges: `20`
- causal_hints_are_soft: `True`
- original_gss_hints_retained: `True`
- top20_prompt_est_tokens: `4752`
- top10_recommended: `False`
- prompt_diff: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_guarded_edge_seed2025/sp_st_prompt_check/prompt_diff.md`

## Metrics

| group | status | causal coverage | violation rate | low evidence | action JS | device JS | transition JS | TOF kept | TOF count | raw count | avg length | note |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| enhanced | ok | 0.583820 | 0.066180 | 0.400000 | 0.647178 | 0.425412 | 0.965066 | 0.952381 | 40 | 42 | 4.425000 |  |

## Commands

- enhanced generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_sp_st.py --stage generate --groups enhanced --threshold 0.915 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --force-tof --edge-guard target-overrepresented --edge-guard-reference-tof-pkl outputs/gcad_gss/sp_st_codex_calibrated_seed2025/sp_st_original/smartgen_tof.pkl --sparse-threshold 0.0 --epochs 80 --sample-limit 64 --seed 2025 --samples-per-category 6 --output-tag sp_st_guarded_edge_seed2025`
- enhanced TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_sp_st.py --stage tof --groups enhanced --threshold 0.915 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --force-tof --edge-guard target-overrepresented --edge-guard-reference-tof-pkl outputs/gcad_gss/sp_st_codex_calibrated_seed2025/sp_st_original/smartgen_tof.pkl --sparse-threshold 0.0 --epochs 80 --sample-limit 64 --seed 2025 --samples-per-category 6 --output-tag sp_st_guarded_edge_seed2025`
- enhanced generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_guarded_edge_seed2025/sp_st_enhanced/generation_manifest.json`
- enhanced tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_guarded_edge_seed2025/sp_st_enhanced/tof_manifest.json`
- enhanced quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_guarded_edge_seed2025/sp_st_enhanced/quality_eval_manifest.json`
