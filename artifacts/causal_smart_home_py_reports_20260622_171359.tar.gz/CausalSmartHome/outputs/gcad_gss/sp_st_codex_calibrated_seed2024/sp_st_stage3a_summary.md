# SP-ST Stage 3A GCAD-GSS Prompt Quality Summary

This summary compares SmartGen original prompt vs SmartGen + GCAD-GSS enhanced prompt at generation-quality level only. No downstream AD claim is made.

## Prompt Check

- top20_edges: `20`
- causal_hints_are_soft: `True`
- original_gss_hints_retained: `True`
- top20_prompt_est_tokens: `4752`
- top10_recommended: `False`
- prompt_diff: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_prompt_check/prompt_diff.md`

## Metrics

| group | status | causal coverage | violation rate | low evidence | action JS | device JS | transition JS | TOF kept | TOF count | raw count | avg length | note |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| original | ok | 0.449719 | 0.050281 | 0.578947 | 0.663270 | 0.439997 | 0.972252 | 0.904762 | 38 | 42 | 4.078947 |  |
| enhanced | ok | 0.507527 | 0.048029 | 0.472222 | 0.682732 | 0.452759 | 0.978157 | 0.857143 | 36 | 42 | 4.138889 |  |

## Commands

- original generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_sp_st.py --stage generate --groups original --threshold 0.915 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --force-tof --sparse-threshold 0.0 --epochs 80 --sample-limit 64 --seed 2024 --samples-per-category 6 --output-tag sp_st_codex_calibrated_seed2024`
- original TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_sp_st.py --stage tof --groups original --threshold 0.915 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --force-tof --sparse-threshold 0.0 --epochs 80 --sample-limit 64 --seed 2024 --samples-per-category 6 --output-tag sp_st_codex_calibrated_seed2024`
- original generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_original/generation_manifest.json`
- original tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_original/tof_manifest.json`
- original quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_original/quality_eval_manifest.json`
- enhanced generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_sp_st.py --stage generate --groups enhanced --threshold 0.915 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --force-tof --sparse-threshold 0.0 --epochs 80 --sample-limit 64 --seed 2024 --samples-per-category 6 --output-tag sp_st_codex_calibrated_seed2024`
- enhanced TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_sp_st.py --stage tof --groups enhanced --threshold 0.915 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --force-tof --sparse-threshold 0.0 --epochs 80 --sample-limit 64 --seed 2024 --samples-per-category 6 --output-tag sp_st_codex_calibrated_seed2024`
- enhanced generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_enhanced/generation_manifest.json`
- enhanced tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_enhanced/tof_manifest.json`
- enhanced quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2024/sp_st_enhanced/quality_eval_manifest.json`
