# Stage 3B AD Check: SP-ST GCAD-GSS Prompt

## Protocol

- Dataset: SP-ST only.
- Compared synthetic spring sequences from Stage 3A after SmartGen TOF.
- The two arms reuse the same SmartGen AD wrapper, target test data, attack data, seed, split ratio, epochs, and threshold percentile.
- No SmartGuard training was run.
- This is a downstream AD check, not a claim that GCAD-GSS improves every AD setting.

## Metrics

| group | precision | recall | F1 | FPR | FNR | accuracy | TP | TN | FP | FN | threshold | synthetic |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| original_prompt | 0.270916 | 0.093407 | 0.138917 | 0.251374 | 0.906593 | 0.421016 | 68 | 545 | 183 | 660 | 3.899684 | 41 |
| enhanced_prompt | 0.321569 | 0.112637 | 0.166836 | 0.237637 | 0.887363 | 0.437500 | 82 | 555 | 173 | 646 | 2.345346 | 37 |

## Delta Enhanced Minus Original

- delta_precision: `0.050652`
- delta_recall: `0.019231`
- delta_F1: `0.027919`
- delta_FPR: `-0.013736`
- delta_FNR: `-0.019231`
- delta_accuracy: `0.016484`
- delta_learned_threshold: `-1.554338`

## Used Data

- original_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_codex_calibrated_seed2026/sp_st_original/smartgen_tof.pkl`
- enhanced_tof: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/sp_st_guarded_edge_seed2026/sp_st_enhanced/smartgen_tof.pkl`
- attack_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/attack/sp/labeled_sp_spring_attack_heater.pkl`
- target_test_pkl: `/home/heyang/projects/SmartGen/anomaly_detection_pipeline/test/sp/spring/test.pkl`

## Settings

- epochs: `15`
- seed: `2026`
- split_ratio: `0.8`
- device: `cpu`
- cuda_visible_devices: `0`
- threshold_percentage: `95.0`
- dry_run: `False`
