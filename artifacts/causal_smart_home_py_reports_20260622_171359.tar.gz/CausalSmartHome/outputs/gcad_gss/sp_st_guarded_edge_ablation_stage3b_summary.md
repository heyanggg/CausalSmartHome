# SP-ST Stage 3B Repeat Robustness

Codex-calibrated generation setting. SmartGen TOF, target test data, attack data, and Transformer Autoencoder evaluation are unchanged within each run.

## Delta Mean

| metric | enhanced-original mean | std |
| --- | ---: | ---: |
| precision | 0.018754 | 0.059857 |
| recall | 0.085623 | 0.092231 |
| F1 | 0.049381 | 0.059022 |
| FPR | 0.009615 | 0.056619 |
| FNR | -0.085623 | 0.092231 |
| accuracy | 0.038004 | 0.065220 |
| learned_threshold | -1.397181 | 0.597165 |

## Per Seed

| repeat | F1 Δ | FPR Δ | accuracy Δ | precision Δ | recall Δ |
| --- | ---: | ---: | ---: | ---: | ---: |
| seed2024 | 0.004093 | 0.074176 | -0.013736 | -0.050296 | 0.046703 |
| seed2025 | 0.116132 | -0.031593 | 0.111264 | 0.055907 | 0.190934 |
| seed2026 | 0.027919 | -0.013736 | 0.016484 | 0.050652 | 0.019231 |

## Run Paths

- seed2024: `outputs/gcad_gss/sp_st_stage3b_ad_guarded/sp_st_guarded_edge_seed2024/metrics.json`
- seed2025: `outputs/gcad_gss/sp_st_stage3b_ad_guarded/sp_st_guarded_edge_seed2025/metrics.json`
- seed2026: `outputs/gcad_gss/sp_st_stage3b_ad_guarded/sp_st_guarded_edge_seed2026/metrics.json`
