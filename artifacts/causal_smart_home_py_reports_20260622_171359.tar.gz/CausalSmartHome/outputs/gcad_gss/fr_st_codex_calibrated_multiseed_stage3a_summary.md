# FR-ST Stage 3A Repeat Robustness

Fixed sparse-threshold=0.001. Generation quality only; no downstream AD claim is made.

## Delta Mean

| metric | enhanced-original mean | std |
| --- | ---: | ---: |
| causal_coverage | -0.040712 | 0.008331 |
| low_evidence_rate | -0.013891 | 0.009022 |
| violation_rate | 0.054603 | 0.004072 |
| action_js_to_target | -0.053550 | 0.002911 |
| device_js_to_target | -0.033000 | 0.000586 |
| transition_js_to_target | 0.016722 | 0.004791 |
| tof_kept_rate | -0.004505 | 0.066355 |
| generated_count | -1.000000 | 14.730920 |
| average_sequence_length | 0.419534 | 0.074984 |

## Per Repeat

| repeat | coverage Δ | low evidence Δ | violation Δ | action JS Δ | device JS Δ | transition JS Δ | TOF kept Δ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| seed2024 | -0.031092 | -0.023207 | 0.054299 | -0.054986 | -0.032495 | 0.013604 | 0.009009 |
| seed2025 | -0.045497 | -0.005195 | 0.050692 | -0.055464 | -0.033643 | 0.022239 | 0.054054 |
| seed2026 | -0.045546 | -0.013272 | 0.058818 | -0.050200 | -0.032864 | 0.014324 | -0.076577 |

## Run Paths

- seed2024: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_stage3a_summary.csv`
- seed2025: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2025/fr_st_stage3a_summary.csv`
- seed2026: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_seed2026/fr_st_stage3a_summary.csv`
