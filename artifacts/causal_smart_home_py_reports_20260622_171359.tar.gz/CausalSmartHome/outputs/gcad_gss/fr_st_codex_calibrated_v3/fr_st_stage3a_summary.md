# FR-ST Stage 3A GCAD-GSS Prompt Quality Summary

This summary compares SmartGen original prompt vs SmartGen + GCAD-GSS enhanced prompt at generation-quality level only. No downstream AD claim is made.

## Prompt Check

- top20_edges: `1`
- causal_hints_are_soft: `True`
- original_gss_hints_retained: `True`
- top20_prompt_est_tokens: `4923`
- top10_recommended: `False`
- prompt_diff: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_prompt_check/prompt_diff.md`

## Metrics

| group | status | causal coverage | violation rate | low evidence | action JS | device JS | transition JS | TOF kept | TOF count | raw count | avg length | note |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| original | ok | 0.553201 | 0.021679 | 0.425121 | 0.478416 | 0.245736 | 0.789145 | 0.932432 | 207 | 222 | 4.985507 |  |
| enhanced | ok | 0.522109 | 0.075977 | 0.401914 | 0.423431 | 0.213242 | 0.802749 | 0.941441 | 209 | 222 | 5.387560 |  |

## Commands

- original generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage generate --groups original --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --require-cuda --sparse-threshold 0.001 --epochs 80 --sample-limit 64 --seed 2024 --samples-per-category 6 --output-tag fr_st_codex_calibrated_v3`
- original TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage tof --groups original --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --require-cuda --sparse-threshold 0.001 --epochs 80 --sample-limit 64 --seed 2024 --samples-per-category 6 --output-tag fr_st_codex_calibrated_v3`
- original generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_original/generation_manifest.json`
- original tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_original/tof_manifest.json`
- original quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_original/quality_eval_manifest.json`
- enhanced generation: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage generate --groups enhanced --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --require-cuda --sparse-threshold 0.001 --epochs 80 --sample-limit 64 --seed 2024 --samples-per-category 6 --output-tag fr_st_codex_calibrated_v3`
- enhanced TOF: `/home/heyang/miniconda3/envs/smartguard_env/bin/python scripts/run_stage3a_gcad_gss_fr_st.py --stage tof --groups enhanced --threshold 0.918 --method SPPC --llm-model gpt-4o-2024-11-20 --offline-generator codex-calibrated --require-cuda --sparse-threshold 0.001 --epochs 80 --sample-limit 64 --seed 2024 --samples-per-category 6 --output-tag fr_st_codex_calibrated_v3`
- enhanced generation_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_enhanced/generation_manifest.json`
- enhanced tof_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_enhanced/tof_manifest.json`
- enhanced quality_manifest: `/home/heyang/projects/CausalSmartHome/outputs/gcad_gss/fr_st_codex_calibrated_v3/fr_st_enhanced/quality_eval_manifest.json`
