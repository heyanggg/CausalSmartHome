import argparse
import datetime
import json
import os
import time

import pandas as pd

from model import SASRec
from transsas import Transsas_test, Transsas
from utils import *

vocab_dic = {"an": 141, "fr": 222, "us": 268, "sp": 234}


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)

    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def str2bool(s):
    if s not in {'false', 'true'}:
        raise ValueError('Not a valid boolean string')
    return s == 'true'


def SASRec_behavior_prediction(nation, new_env, threshold, method, model, need):
    if need == 'train':
        Transsas(nation, new_env, threshold, method, model)
        parser = argparse.ArgumentParser()
        parser.add_argument('--dataset', default=f'{nation}_{new_env}_generation_{method}_th={threshold}_{model}_seq')
        parser.add_argument('--train_dir', default='default')
        parser.add_argument('--batch_size', default=8, type=int)
        parser.add_argument('--lr', default=0.001, type=float)
        parser.add_argument('--maxlen', default=200, type=int)
        parser.add_argument('--hidden_units', default=50, type=int)
        parser.add_argument('--num_blocks', default=2, type=int)
        parser.add_argument('--num_epochs', default=50, type=int)
        parser.add_argument('--num_heads', default=1, type=int)
        parser.add_argument('--dropout_rate', default=0.2, type=float)
        parser.add_argument('--l2_emb', default=0.0, type=float)
        parser.add_argument('--device', default='cuda', type=str)

        parser.add_argument('--inference_only', default=False, type=str2bool)
        parser.add_argument('--state_dict_path', default=None, type=str)

    elif need == 'test':
        Transsas_test(nation, new_env)
        parser = argparse.ArgumentParser()
        parser.add_argument('--dataset', default=f'{nation}_{new_env}_test')
        parser.add_argument('--train_dir', default='default')
        parser.add_argument('--batch_size', default=8, type=int)
        parser.add_argument('--lr', default=0.001, type=float)
        parser.add_argument('--maxlen', default=200, type=int)
        parser.add_argument('--hidden_units', default=50, type=int)
        parser.add_argument('--num_blocks', default=2, type=int)
        parser.add_argument('--num_epochs', default=50, type=int)
        parser.add_argument('--num_heads', default=1, type=int)
        parser.add_argument('--dropout_rate', default=0.2, type=float)
        parser.add_argument('--l2_emb', default=0.0, type=float)
        parser.add_argument('--device', default='cuda', type=str)

        parser.add_argument('--inference_only', default=True, type=str2bool)
        parser.add_argument('--state_dict_path',
                            default=f'{nation}_{new_env}_generation_{method}_th={threshold}_{model}_seq_default/SASRec.epoch=50.lr=0.001.layer=2.head=1.hidden=50.maxlen=200.pth',
                            type=str)

    args = parser.parse_args()
    if not os.path.isdir(args.dataset + '_' + args.train_dir):
        os.makedirs(args.dataset + '_' + args.train_dir)
    with open(os.path.join(args.dataset + '_' + args.train_dir, 'args.txt'), 'w') as f:
        f.write('\n'.join([str(k) + ',' + str(v) for k, v in sorted(vars(args).items(), key=lambda x: x[0])]))
    f.close()

    setup_seed(2024)
    u2i_index, i2u_index = build_index(args.dataset)

    dataset = data_partition(args.dataset)

    [user_train, user_valid, user_test, usernum, _] = dataset
    itemnum = vocab_dic[nation]

    num_batch = (len(user_train) - 1) // args.batch_size + 1
    cc = 0.0
    for u in user_train:
        cc += len(user_train[u])
    print('average sequence length: %.2f' % (cc / len(user_train)))

    f = open(os.path.join(args.dataset + '_' + args.train_dir, 'log.txt'), 'w')
    f.write('epoch (val_ndcg, val_hr) (test_ndcg, test_hr)\n')

    sampler = WarpSampler(user_train, usernum, itemnum, batch_size=args.batch_size, maxlen=args.maxlen, n_workers=3)
    model = SASRec(usernum, itemnum, args).to(args.device)

    for name, param in model.named_parameters():
        try:
            torch.nn.init.xavier_normal_(param.data)
        except:
            pass

    model.pos_emb.weight.data[0, :] = 0
    model.item_emb.weight.data[0, :] = 0

    model.train()

    epoch_start_idx = 1
    if args.state_dict_path is not None:
        try:
            model.load_state_dict(torch.load(args.state_dict_path, map_location=torch.device(args.device)))
            tail = args.state_dict_path[args.state_dict_path.find('epoch=') + 6:]
            epoch_start_idx = int(tail[:tail.find('.')]) + 1
        except Exception as e:
            print(e)
            print('failed loading state_dicts, pls check file path: ', end="")
            print(args.state_dict_path)
            print('pdb enabled for your quick check, pls type exit() if you do not need it')
            import pdb;
            pdb.set_trace()

    if args.inference_only:
        model.eval()
        t_test = evaluate(model, dataset, args)
        print('test (NDCG@10: %.4f, HR@10: %.4f)' % (t_test[0], t_test[1]))
        return {
            'HR@10': t_test[1],
            'NDCG@10': t_test[0],
        }

    bce_criterion = torch.nn.BCEWithLogitsLoss()
    adam_optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, betas=(0.9, 0.98))

    best_val_ndcg, best_val_hr = 0.0, 0.0
    best_test_ndcg, best_test_hr = 0.0, 0.0
    T = 0.0
    t0 = time.time()
    for epoch in range(epoch_start_idx, args.num_epochs + 1):
        if args.inference_only: break
        for step in range(num_batch):
            u, seq, pos, neg = sampler.next_batch()
            u, seq, pos, neg = np.array(u), np.array(seq), np.array(pos), np.array(neg)
            pos_logits, neg_logits = model(u, seq, pos, neg)
            pos_labels, neg_labels = torch.ones(pos_logits.shape, device=args.device), torch.zeros(neg_logits.shape,
                                                                                                   device=args.device)

            adam_optimizer.zero_grad()
            indices = np.where(pos != 0)
            loss = bce_criterion(pos_logits[indices], pos_labels[indices])
            loss += bce_criterion(neg_logits[indices], neg_labels[indices])
            for param in model.item_emb.parameters(): loss += args.l2_emb * torch.norm(param)
            loss.backward()
            adam_optimizer.step()
            print("loss in epoch {} iteration {}: {}".format(epoch, step, loss.item()))

        if epoch % 20 == 0:
            model.eval()
            t1 = time.time() - t0
            T += t1
            print('Evaluating', end='')
            t_test = evaluate(model, dataset, args)
            t_valid = evaluate_valid(model, dataset, args)
            print('epoch:%d, time: %f(s), valid (NDCG@10: %.4f, HR@10: %.4f), test (NDCG@10: %.4f, HR@10: %.4f)'
                  % (epoch, T, t_valid[0], t_valid[1], t_test[0], t_test[1]))

            if t_valid[0] > best_val_ndcg or t_valid[1] > best_val_hr or t_test[0] > best_test_ndcg or t_test[
                1] > best_test_hr:
                best_val_ndcg = max(t_valid[0], best_val_ndcg)
                best_val_hr = max(t_valid[1], best_val_hr)
                best_test_ndcg = max(t_test[0], best_test_ndcg)
                best_test_hr = max(t_test[1], best_test_hr)
                folder = args.dataset + '_' + args.train_dir
                fname = 'SASRec.epoch={}.lr={}.layer={}.head={}.hidden={}.maxlen={}.pth'
                fname = fname.format(epoch, args.lr, args.num_blocks, args.num_heads, args.hidden_units, args.maxlen)
                torch.save(model.state_dict(), os.path.join(folder, fname))

            f.write(str(epoch) + ' ' + str(t_valid) + ' ' + str(t_test) + '\n')
            f.flush()
            t0 = time.time()
            model.train()

        if epoch == args.num_epochs:
            folder = args.dataset + '_' + args.train_dir
            fname = 'SASRec.epoch={}.lr={}.layer={}.head={}.hidden={}.maxlen={}.pth'
            fname = fname.format(args.num_epochs, args.lr, args.num_blocks, args.num_heads, args.hidden_units,
                                 args.maxlen)
            torch.save(model.state_dict(), os.path.join(folder, fname))

    f.close()
    sampler.close()
    print("Done")


if __name__ == '__main__':
    setup_seed(2024)
    start_time = datetime.datetime.now()
    datasets = ["fr", "sp", "us"]

    environments = ["spring", "night", "multiple"]
    thres = ['0.918', '0.92', '0.915', '0.915', '0.917', '0.915', '0.905', '0.919', '0.913']
    results = []
    i = 0
    for nation in datasets:
        for new_env in environments:
            threshold = thres[i]
            i += 1
            # SASRec_behavior_prediction(nation, new_env, threshold, "SPPC", "gpt-4o", 'train')
            test_metrics = SASRec_behavior_prediction(nation, new_env, threshold, "SPPC", "gpt-4o", 'test')
            result = {
                'dataset': nation,
                'environment': new_env,
                'model': 'SASRec_fixed',
                **test_metrics
            }
            results.append(result)
    if results:
        results_df = pd.DataFrame(results)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        results_file = f"results/action_only_results_{timestamp}.csv"
        os.makedirs("results", exist_ok=True)
        results_df.to_csv(results_file, index=False)
        results_json = f"results/action_only_results_{timestamp}.json"
        with open(results_json, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        print(f"\nResults saved:")
        print(f"CSV: {results_file}")
        print(f"JSON: {results_json}")
        print(f"\n{'=' * 50}")
        print("Experiment results summary:")
        print(f"{'=' * 50}")
        print(results_df.to_string(index=False))
        print(f"\nAverage performance:")
        for metric in ['HR@10', 'NDCG@10']:
            avg_value = results_df[metric].mean()
            print(f"  {metric}: {avg_value:.4f}")
    end_time = datetime.datetime.now()
    duration = end_time - start_time
    print(f"\nEnd time: {end_time}")
    print(f"Total duration: {duration}")
